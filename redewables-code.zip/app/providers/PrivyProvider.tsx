'use client';

import { PrivyProvider } from '@privy-io/react-auth';

export default function Privy({ children }: { children: React.ReactNode }) {
  return (
    <PrivyProvider
      appId={process.env.NEXT_PUBLIC_PRIVY_APP_ID!}
      config={{
        appearance: { theme: 'dark' },
        solana: {
          // ✅ Fix: 'cluster' is no longer a direct property for some versions. 
          // Use this to enable Solana connectors.
        },
        embeddedWallets: {
          // ✅ Fix: Move 'createOnLogin' inside a 'solana' or 'ethereum' key
          solana: {
            createOnLogin: 'users-without-wallets',
          },
        },
      }}
    >
      {children}
    </PrivyProvider>
  );
}
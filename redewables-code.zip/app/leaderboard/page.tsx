'use client';

import Link from 'next/link';
import { useWallet } from '@solana/wallet-adapter-react';
import { useWalletModal } from '@solana/wallet-adapter-react-ui';
import MintGate from '../components/MintGate';
import Leaderboard from '../components/Leaderboard';

export default function LeaderboardPage() {
  const { connected, publicKey } = useWallet();
  const { setVisible } = useWalletModal();

  if (!connected) {
    return (
      <div className="dashboard-container">
        <div className="grid-floor"></div>
        <div className="connect-prompt">
          <div className="connect-box glass-panel p-12 rounded-[2rem] text-center">
            <div className="logo text-4xl mb-4">RE<span>DEW</span></div>
            <h1 className="text-xl font-black italic tracking-tighter mb-2 uppercase">Leaderboard</h1>
            <p className="text-gray-500 text-sm mb-8">Connect your wallet to view network rankings</p>
            <button className="connect-btn" onClick={() => setVisible(true)}>Initialize Connection</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <MintGate>
      <div className="dashboard-container">
        <div className="testnet-banner font-mono">⚠️ NETWORK_STATUS: DEVNET_ACTIVE</div>
        <div className="grid-floor"></div>

        <main className="main-content" style={{ maxWidth: 1100 }}>
          <div className="page-header mb-10">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h1 className="page-title italic font-black tracking-tighter uppercase">Network_Rankings</h1>
                <div className="text-[10px] font-mono uppercase tracking-[0.22em] text-gray-500 mt-2">
                  Global validator standings • rolling 24h
                </div>
              </div>

              <div className="flex items-center gap-2 mt-2">
                <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[10px] font-mono uppercase tracking-[0.22em] text-emerald-400">
                  Live
                </span>
              </div>
            </div>

            <div className="mt-6">
              <Link href="/dashboard" className="back-link">← Back to Dashboard</Link>
            </div>

            <div className="mt-4 text-[10px] font-mono uppercase tracking-[0.22em] text-gray-600">
              Validator_ID: {publicKey?.toString().slice(0, 4)}...{publicKey?.toString().slice(-4)}
            </div>
          </div>

          {/* IMPORTANT: create a local stacking context and mask any global background bleed */}
          <section className="glass-panel p-8 rounded-[2rem] border-emerald-500/10 shadow-[0_0_60px_rgba(16,185,129,0.06)] relative overflow-hidden">
            {/* Black mask behind content to prevent bleed from global visuals */}
            <div className="absolute inset-0 bg-black/55 pointer-events-none" />
            {/* subtle scanline texture */}
            <div
              className="absolute inset-0 pointer-events-none opacity-[0.08]"
              style={{
                backgroundImage:
                  'linear-gradient(rgba(255,255,255,0.06) 1px, transparent 1px)',
                backgroundSize: '100% 6px',
              }}
            />
            <div className="relative">
              <Leaderboard />
            </div>
          </section>
        </main>
      </div>
    </MintGate>
  );
}
import { NextRequest, NextResponse } from 'next/server';
import { createUmi } from '@metaplex-foundation/umi-bundle-defaults';
import { create, mplCore, fetchCollection } from '@metaplex-foundation/mpl-core';
import { keypairIdentity, generateSigner, publicKey } from '@metaplex-foundation/umi';
import { irysUploader } from '@metaplex-foundation/umi-uploader-irys';
import { createClient } from '@supabase/supabase-js';
import { Connection } from '@solana/web3.js';

export const dynamic = 'force-dynamic';

const DEVNET_RPC = 'https://api.devnet.solana.com';
const TREASURY_WALLET = 'E4ZDgh4a6gUuCANfWTCAzXpTRUA72zC1vosDMQinayHc'; 
const COLLECTION_ADDRESS = process.env.NEXT_PUBLIC_COLLECTION_ADDRESS || 'g2JyfrSNHEeT9CNYwvANNcLwonPMx5DNDnQaLAwY4oV';

const TIERS = {
  genesis: { name: 'ReDew Genesis License', symbol: 'REDEW-G', tier: 'Genesis', multiplier: '1.5x', image: 'https://gateway.irys.xyz/6NDA34ypC29jq8ckcVzQWECuPQ7FxxbmQrcu5n4uRoU' },
  core: { name: 'ReDew Core License', symbol: 'REDEW-C', tier: 'Core', multiplier: '1.0x', image: 'https://gateway.irys.xyz/FZo8XbdCgfBGTTQtkmvssD4Tdvy5ozr62yD5NyKoXhFM' },
  surge: { name: 'ReDew Surge License', symbol: 'REDEW-S', tier: 'Surge', multiplier: '2.0x', image: 'https://gateway.irys.xyz/6r8Cq11bF4xjySnnQSxqTQWeZB4chK3FSottP9w6mF1r' },
};

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);
    const authSecret = process.env.SOLANA_AUTHORITY_SECRET_KEY;
    const { tier, recipient, paymentSignature, quantity = 1 } = await request.json();

    // 1. Idempotency Check
    const { data: existing } = await supabase.from('licenses').select('nft_address').eq('payment_tx', paymentSignature);
    if (existing && existing.length > 0) {
      return NextResponse.json({ success: true, nftAddresses: existing.map(r => r.nft_address) });
    }

    // 2. Payment Verification
    const connection = new Connection(DEVNET_RPC, 'confirmed');
    const tx = await connection.getTransaction(paymentSignature, { commitment: 'confirmed', maxSupportedTransactionVersion: 0 });
    if (!tx) return NextResponse.json({ error: 'Transaction not found' }, { status: 400 });

    // 3. Setup Umi
    const umi = createUmi(DEVNET_RPC).use(mplCore()).use(irysUploader());
    const keypair = umi.eddsa.createKeypairFromSecretKey(new Uint8Array(JSON.parse(authSecret!)));
    umi.use(keypairIdentity(keypair));

    const collection = await fetchCollection(umi, publicKey(COLLECTION_ADDRESS));
    const tierData = TIERS[tier as keyof typeof TIERS];
    const mintedAddresses: string[] = [];

    // 4. Database: Identify User
    const { data: userRow } = await supabase.from('users').upsert({ wallet_address: recipient }, { onConflict: 'wallet_address' }).select('id').single();

    // 5. Minting Loop
    for (let i = 1; i <= quantity; i++) {
      const assetSigner = generateSigner(umi);
      const uri = await umi.uploader.uploadJson({
        name: tierData.name,
        symbol: tierData.symbol,
        image: tierData.image,
        attributes: [{ trait_type: 'Tier', value: tierData.tier }, { trait_type: 'Multiplier', value: tierData.multiplier }]
      });

      await create(umi, { asset: assetSigner, collection, name: tierData.name, uri, owner: publicKey(recipient) }).sendAndConfirm(umi);
      
      const nftAddress = assetSigner.publicKey.toString();
      mintedAddresses.push(nftAddress);

      await supabase.from('licenses').insert({
        user_id: userRow?.id,
        wallet_address: recipient,
        tier,
        nft_address: nftAddress,
        payment_tx: paymentSignature,
        mint_status: 'minted'
      });
    }

    return NextResponse.json({ success: true, nftAddresses: mintedAddresses });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}